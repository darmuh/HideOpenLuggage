### This is a simple mod that hides luggage bags that have already been opened. 

Either instantly hide the opened luggage bags when opened or set a configurable delay.


NOTE: The configuration options for this mod will be found in the configuration file named ``com.github.darmuh.HideOpenLuggage.cfg`` which is created in the ``Bepinex\config`` folder after launching the game with this mod installed.